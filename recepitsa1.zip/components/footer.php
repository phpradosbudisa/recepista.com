<footer style="margin-top:0;">
    <div class="row">
        <div class="col-sm-6 col-md-4 footer-navigation">
            <h3><a href="#" style="font-family:'Montserrat Alternates', sans-serif;">rECEPISTa</a></h3>
            <p class="links" style="font-family:'Montserrat Alternates', sans-serif;"><a href="#">Početna</a><strong> ·&nbsp;</strong><a
                    href="#">Novosti</a><strong> · </strong><a href="#">Recepti</a><strong>&nbsp;</strong><a
                    href="#"></a></p>
            <p class="company-name" style="font-family:'Montserrat Alternates', sans-serif;">rECEPISTa &nbsp;© 2018 Sva
                prava zadržana.</p>
        </div>
        <div class="col-sm-6 col-md-4 footer-contacts">
            <div>
                <h4 style="font-size:1rem;font-family:'Montserrat Alternates', sans-serif;">Gdje se nalazimo :</h4><span
                    class="fa fa-map-marker footer-contacts-icon"> </span>
                <p style="font-family:'Montserrat Alternates', sans-serif;"> Banja Luka - RS, BIH</p>
            </div>
            <div></div>
            <div>
                <h4 style="font-size:1rem;font-family:'Montserrat Alternates', sans-serif;">Pridruzite se timu!</h4>
                <p style="color:rgb(146,153,159);line-height:20px;font-size:13px;font-family:'Montserrat Alternates', sans-serif;font-weight:normal;">
                    Ukoliko želite da budete dio tima rECEPISTa pošaljite prijavu na sledeću adresu:</p>
                <p>
                    <i
                        class="fa fa-envelope footer-contacts-icon"></i>
                    <a href="#" target="_blank"
                       style="color:rgb(255,255,255);font-family:'Montserrat Alternates', sans-serif;">i-ja-sam@recepista.com</a>
                </p>
            </div>
        </div>
        <div class="clearfix"></div>
        <div class="col-md-4 footer-about">
            <h4 style="font-size:1rem;font-family:'Montserrat Alternates', sans-serif;">O nama</h4>
            <p class="text-justify" style="font-family:'Montserrat Alternates', sans-serif;line-height:15px;"> Mi smo
                informativni portal za gurmane. Ovim portalom želimo da pojednostavimo i olakšamo svakondevnu borbu s
                pitanjem "Šta danas da skuhamo?". Nadamo se da će Vam naši recepti pomoći i da će biti korisni kada ih
                zatrebate.</p>
            <div style="margin-bottom: 25px" class="social-links social-icons"><a href="https://www.facebook.com/srr.ecepist.a/"><i
                        class="fa fa-facebook"></i></a></div>
            <form class="form-inline d-flex flex-row justify-content-center" method="post"
                  action="components/subscribe.php">
                <div class="form-group d-flex" style="width:100%;"><input class="form-control" type="email"
                                                                          name="email"
                                                                          placeholder="Vasa email adresa:"
                                                                          autocomplete="off">
                    <button class="btn btn-primary" type="submit" name="submit"
                            style="background-color:#33383b;border: 1px solid #a9a9a9">Pretplati me!
                    </button>
                </div>
            </form>
        </div>
    </div>
</footer>