<?php
/**
 * Created by PhpStorm.
 * User: Rados
 * Date: 12/22/2018
 * Time: 10:55 PM
 */

include 'config.php';

function displayTopRecepies($limit)
{
    $conn = new PDO("mysql:host=" . DBHOST . ";dbname=" . DBNAME, DBUSER, DBPASS);
    $get = $conn->prepare("select * from recepti where top = 'Yes' LIMIT $limit");
    $get->execute();
    $data = $get->fetchAll();
    foreach ($data as $recipe) {
        echo '
              <div class="col-sm-6 col-md-4 col-lg-4 col-xl-4 d-flex flex-row justify-content-center">
                <figure class="snip1527">
                    <div class="image">
                    <img src="' . $recipe["img_url"] . '"alt="pr-sample23"/>
                    </div>
                    <figcaption>
                        <div class="date"><span class="day">28</span><span class="month">Oct</span></div>
                        <h3>' . $recipe["title"] . '</h3>
                        <p>' . $recipe["short_details"] . '</p>
                    </figcaption>
                    <a href="#"></a>
                </figure>
            </div>';
    }
}


function displayDailyRecipes($limit)
{
    $conn = new PDO("mysql:host=" . DBHOST . ";dbname=" . DBNAME, DBUSER, DBPASS);
    $get = $conn->prepare("select * from recepti  LIMIT $limit");
    $get->execute();
    $data = $get->fetchAll();
    foreach ($data as $recipe) {
        echo '<div class="col-xs-2 col-12 col-sm-6 col-lg-4 col-xl-3 offset-xl-0 d-flex flex-row justify-content-center item"
                 style="padding:1.5em 15px;">
                <div class="block span3">
                    <div class="product">
                        <img style="max-height:280px;" class="img-fluid" src="' . $recipe["img_url"] . '">
                    </div>
                    
                    <div class="info">
                        <h4>' . $recipe["title"] . '</h4>
                        <span class="description">
                            ' . $recipe["short_details"] . '
                         </span>
                        <span class="price">' . $recipe["category"] . '</span>
                        <a class="btn btn-info pull-right" href="#"><i class="icon-shopping-cart"></i>Priprema</a>
                    </div>
                    <div class="details">
                        <span class="time"><i class="icon-time"></i>' . $recipe["toughnes"] . '</span>
                        <span class="rating pull-right">';

        switch ($recipe["toughnes"]) {
            case 'Lagano':
                echo '<span class="star"></span>';
                break;
            case 'Normalno':
                echo '<span class="star"></span>
                                          <span class="star"></span>';
                break;
            case 'Komplikovano':
                echo '<span class="star"></span>
                                          <span class="star"></span>
                                          <span class="star"></span>';
                break;
            case 'Veoma zahtjevno':
                echo '<span class="star"></span>
                                          <span class="star"></span>
                                          <span class="star"></span>
                                          <span class="star"></span>';
                break;
            default:
                echo '<span class="star"></span>
                                          <span class="star"></span>
                                          <span class="star"></span>
                                          <span class="star"></span>
                                          <span class="star"></span>';
        }

        echo '
                         </span>
                    </div>
                </div>
            </div>';
    }
}


function displayRecipes($limit)
{
    $conn = new PDO("mysql:host=" . DBHOST . ";dbname=" . DBNAME, DBUSER, DBPASS);
    $get = $conn->prepare("select * from recepti  LIMIT $limit");
    $get->execute();
    $data = $get->fetchAll();
    foreach ($data as $recipe) {
        echo '<div class="col-xs-2 col-12 col-sm-6 col-lg-4 col-xl-3 offset-xl-0 d-flex flex-row justify-content-center item"
                 style="padding:1.5em 15px;">
                <div class="block span3">
                    <div class="product">
                        <img style="max-height:280px;" class="img-fluid" src="' . $recipe["img_url"] . '">
                    </div>
                    
                    <div class="info">
                        <h4>' . $recipe["title"] . '</h4>
                        <span class="description">
                            ' . $recipe["short_details"] . '
                         </span>
                        <span class="price">' . $recipe["category"] . '</span>
                        <a class="btn btn-info pull-right" href="#"><i class="icon-shopping-cart"></i>Priprema</a>
                    </div>
                    <div class="details">
                        <span class="time"><i class="icon-time"></i>' . $recipe["toughnes"] . '</span>
                        <span class="rating pull-right">';

        switch ($recipe["toughnes"]) {
            case 'Lagano':
                echo '<span class="star"></span>';
                break;
            case 'Normalno':
                echo '<span class="star"></span>
                                          <span class="star"></span>';
                break;
            case 'Komplikovano':
                echo '<span class="star"></span>
                                          <span class="star"></span>
                                          <span class="star"></span>';
                break;
            case 'Veoma zahtjevno':
                echo '<span class="star"></span>
                                          <span class="star"></span>
                                          <span class="star"></span>
                                          <span class="star"></span>';
                break;
            default:
                echo '<span class="star"></span>
                                          <span class="star"></span>
                                          <span class="star"></span>
                                          <span class="star"></span>
                                          <span class="star"></span>';
        }

        echo '
                         </span>
                    </div>
                </div>
            </div>';
    }
}