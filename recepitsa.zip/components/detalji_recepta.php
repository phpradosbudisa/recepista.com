<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recepist</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cookie">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat+Alternates:300,400,500">
    <link rel="stylesheet" href="https://daneden.github.io/animate.css/animate.min.css">
    <link rel="stylesheet" href="https://unpkg.com/@bootstrapstudio/bootstrap-better-nav/dist/bootstrap-better-nav.min.css">
    <link rel="stylesheet" href="../assets/css/styles.min.css">
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-131387393-1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', 'UA-131387393-1');
    </script>

</head>

<body>
<section class="flex-row justify-content-center align-items-center" style="height:100vh;">
    <nav class="navbar navbar-light navbar-expand-md">
        <div class="container-fluid"><a href="#" class="navbar-brand" style="background-image:url(assets/img/1recepista.png);"></a><button data-toggle="collapse" data-target="#navcol-1" class="navbar-toggler"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
            <div
                    class="collapse navbar-collapse" id="navcol-1" style="font-size:13px;">
                <ul class="nav navbar-nav mx-auto">
                    <li role="presentation" class="nav-item"><a href="../index.php" class="nav-link active">Početna</a></li>
                    <li role="presentation" class="nav-item"><a href="../recepti.php" class="nav-link">Recepti</a></li>
                    <li role="presentation" class="nav-item"><a href="../o_nama.php" class="nav-link">O nama</a></li>
                </ul>
                <div>
                    <form class="form-inline" method="get" action="../recepti.php">
                        <div class="form-group d-flex" style="width:100%;"><input class="form-control" type="querry"
                                                                                  name="querry"
                                                                                  placeholder="Pretrazi recepte:"
                                                                                  autocomplete="off">
                            <button class="btn btn-primary" type="submit" name="submit"
                                    style="background-color:#33383b;border: 1px solid #a9a9a9">Pretraži!
                            </button>
                        </div>
                    </form>
                </div>
                <ul class="nav navbar-nav">
                    <li role="presentation" class="nav-item"><a href="#" class="nav-link active">Uloguj se</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container-fluid">
        <div class="row">
            <div class="col">
                <div><img class="img-fluid" src="../assets/img/Vegware_concept_bagasse_P005_naanbreadtop_CON0066_1308.jpg" style="padding:8em;"></div>
            </div>
            <div class="col d-flex flex-column justify-content-between">
                <div class="row">
                    <div class="col">				<div class="caption v-middle text-center">
                            <h1 class="cd-headline clip">
                                <span class="blc">Ja sam | </span>
                                <span class="cd-words-wrapper">
			              <b class="is-visible">Majka.</b>
			              <b>Otac.</b>
			              <b>Gurman.</b>
                          <b>Kuhar.</b>
			            </span>
                            </h1>
                        </div></div>
                </div>
                <div class="row">
                    <div class="col">
                        <h1>Heading</h1>
                        <ul>
                            <li>Item 1</li>
                            <li>Item 2</li>
                            <li>Item 3</li>
                            <li>Item 4</li>
                        </ul>
                    </div>
                    <div class="col">
                        <h1>Heading</h1>
                        <ul>
                            <li>Item 1</li>
                            <li>Item 2</li>
                            <li>Item 3</li>
                            <li>Item 4</li>
                        </ul>
                    </div>
                </div>
                <div class="row">
                    <div class="col" style="padding:0;">
                        <div style="height:10em;background-image:url(&quot;assets/img/f2d8350ce4a7d8b773064d40be3b447a.jpg&quot;);width:100%;margin:0;padding:0;"></div>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <h1>Heading</h1>
                        <ul>
                            <li>Item 1</li>
                            <li>Item 2</li>
                            <li>Item 3</li>
                            <li>Item 4</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.0/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/@bootstrapstudio/bootstrap-better-nav/dist/bootstrap-better-nav.min.js"></script>
<script src="../assets/js/script.min.js"></script>
</body>

</html>