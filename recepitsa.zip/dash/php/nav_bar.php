<nav class="navbar navbar-dark navbar-expand-lg fixed-top"
     style="background-size:auto;background-position:right;">
	<div class="container-fluid">
		
		<button class="navbar-toggler" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span
				class="navbar-toggler-icon text-monospace"></span></button>
		<div class="collapse navbar-collapse"
		     id="navcol-1">
			<ul class="nav navbar-nav mx-auto" style="font-size:1.4em;">
				<li class="nav-item" role="presentation"><a class="nav-link" href="recepti.php">Recepti</a>
				</li>
				<li class="nav-item" role="presentation"><a class="nav-link" href="index.php">Blog</a>
				</li>
			</ul>
			<button class="btn btn-primary" type="submit" name="submit" style="background-color:#33383b;border: 1px solid #a9a9a9">Dodaj recept
			</button>
		</div>
	</div>
</nav>