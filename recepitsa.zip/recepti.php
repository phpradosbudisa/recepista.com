<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recepist</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/simple-line-icons.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cookie">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat+Alternates:300,400,500">
    <link rel="stylesheet" href="https://daneden.github.io/animate.css/animate.min.css">
    <link rel="stylesheet"
          href="https://unpkg.com/@bootstrapstudio/bootstrap-better-nav/dist/bootstrap-better-nav.min.css">
    <link rel="stylesheet" href="assets/css/Ladus-Nav-Bar.css">
    <link rel="stylesheet" href="assets/css/nav-logo-center-hamburger.css">
    <link rel="stylesheet" href="assets/css/News-Cards.css">
    <link rel="stylesheet" href="assets/css/Newsletter-Subscription-Form.css">
    <link rel="stylesheet" href="assets/css/Projects-Clean.css">
    <link rel="stylesheet" href="assets/css/Projects-Horizontal.css">
    <link rel="stylesheet" href="assets/css/Shop-item.css">
    <link rel="stylesheet" href="assets/css/Shop-item.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/Pretty-Search-Form.css">
    <link rel="stylesheet" href="assets/css/Pretty-Footer.css">
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-131387393-1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', 'UA-131387393-1');
    </script>

</head>

<style>
    body {
        padding: 0;
        margin: 0;
        box-sizing: border-box;
        height: 100%;
        background: #e5e5e5;
    }

    .form-group {
        margin: 0;
    }
</style>

<body>

<section>

<nav class="navbar navbar-light navbar-expand-md">
    <div class="container-fluid"><a href="#" class="navbar-brand" style="background-image:url(assets/img/1recepista.png);"></a><button data-toggle="collapse" data-target="#navcol-1" class="navbar-toggler"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
        <div
                class="collapse navbar-collapse" id="navcol-1" style="font-size:13px;">
            <ul class="nav navbar-nav mx-auto">
                <li role="presentation" class="nav-item"><a href="index.php" class="nav-link active">Početna</a></li>
                <li role="presentation" class="nav-item"><a href="recepti.php" class="nav-link">Recepti</a></li>
                <li role="presentation" class="nav-item"><a href="o_nama.php" class="nav-link">O nama</a></li>
            </ul>
            <div>
                <form class="form-inline" method="get">
                    <div class="form-group d-flex" style="width:100%;"><input class="form-control" type="querry"
                                                                              name="querry"
                                                                              placeholder="Pretrazi recepte:"
                                                                              autocomplete="off">
                        <button class="btn btn-primary" type="submit" name="submit"
                                style="background-color:#33383b;border: 1px solid #a9a9a9">Pretraži!
                        </button>
                    </div>
                </form>
            </div>
            <ul class="nav navbar-nav">
                <li role="presentation" class="nav-item"><a href="#" class="nav-link active">Uloguj se</a></li>
            </ul>
        </div>
    </div>
</nav>
<div class="container-fluid d-flex flex-row justify-content-center" id="food_container"
     style="margin:0;">

    <div class="row projects" style="margin:5em 0 0 0;width:80%;">
		<?php
			include 'components/config.php';
			function displayDailyRecipes($limit)
			{
				$conn = new PDO("mysql:host=" . DBHOST . ";dbname=" . DBNAME, DBUSER, DBPASS);
				$get = $conn->prepare("select * from recepti  LIMIT $limit");
				$get->execute();
				$data = $get->fetchAll();
				foreach ($data as $recipe) {
					echo '<div class="col-xs-2 col-12 col-sm-6 col-lg-4 col-xl-3 offset-xl-0 d-flex flex-row justify-content-center item"
                 style="padding:1.5em 15px;">
                <div class="block span3">
                    <div class="product">
                        <img style="max-height:280px;" class="img-fluid" src="' . $recipe["img_url"] . '">
                    </div>
                    
                    <div class="info">
                        <h4>' . $recipe["title"] . '</h4>
                        <span class="description">
                            ' . $recipe["short_details"] . '
                         </span>
                        <span class="price">' . $recipe["category"] . '</span>
                        <a class="btn btn-info pull-right" href="#"><i class="icon-shopping-cart"></i>Priprema</a>
                    </div>
                    <div class="details">
                        <span class="time"><i class="icon-time"></i>' . $recipe["toughnes"] . '</span>
                        <span class="rating pull-right">';
					
					switch ($recipe["toughnes"]) {
						case 'Lagano':
							echo '<span class="star"></span>';
							break;
						case 'Normalno':
							echo '<span class="star"></span>
                                          <span class="star"></span>';
							break;
						case 'Komplikovano':
							echo '<span class="star"></span>
                                          <span class="star"></span>
                                          <span class="star"></span>';
							break;
						case 'Veoma zahtjevno':
							echo '<span class="star"></span>
                                          <span class="star"></span>
                                          <span class="star"></span>
                                          <span class="star"></span>';
							break;
						default:
							echo '<span class="star"></span>
                                          <span class="star"></span>
                                          <span class="star"></span>
                                          <span class="star"></span>
                                          <span class="star"></span>';
					}
					
					echo '
                         </span>
                    </div>
                </div>
            </div>';
				}
			}
			
			if (!isset($_GET['querry'])) {
				displayDailyRecipes(20);
			} else {
				$querry = $_GET['querry'];
				$min_lenght = 3;
				
				if (strlen($querry) >= $min_lenght) {
					$conn = new PDO("mysql:host=" . DBHOST . ";dbname=" . DBNAME, DBUSER, DBPASS);
					$get = $conn->prepare("SELECT * FROM recepti WHERE (`title` LIKE '%" . $querry . "%') OR (`short_details` LIKE '%" . $querry . "%') OR (`title` LIKE '%" . $querry . "%')");
					$get->execute();
					$data = $get->fetchAll();
					if (!empty($data)) {
						foreach ($data as $recipe) {
							echo '<div class="col-xs-2  col-sm-6 col-lg-4 col-xl-3 offset-xl-0 d-flex flex-row justify-content-center item"
                 style="padding:1.5em 15px;">
                <div class="block span3">
                    <div class="product">
                        <img style="max-height:280px;" class="img-fluid" src="' . $recipe["img_url"] . '">
                    </div>
                    
                    <div class="info">
                        <h4>' . $recipe["title"] . '</h4>
                        <span class="description">
                            ' . $recipe["short_details"] . '
                         </span>
                        <span class="price">' . $recipe["category"] . '</span>
                        <a class="btn btn-info pull-right" href="#"><i class="icon-shopping-cart"></i>Priprema</a>
                    </div>
                    <div class="details">
                        <span class="time"><i class="icon-time"></i>' . $recipe["toughnes"] . '</span>
                        <span class="rating pull-right">';
							switch ($recipe["toughnes"]) {
								case 'Lagano':
									echo '<span class="star"></span>';
									break;
								case 'Normalno':
									echo '<span class="star"></span>
                                          <span class="star"></span>';
									break;
								case 'Komplikovano':
									echo '<span class="star"></span>
                                          <span class="star"></span>
                                          <span class="star"></span>';
									break;
								case 'Veoma zahtjevno':
									echo '<span class="star"></span>
                                          <span class="star"></span>
                                          <span class="star"></span>
                                          <span class="star"></span>';
									break;
								default:
									echo '<span class="star"></span>
                                          <span class="star"></span>
                                          <span class="star"></span>
                                          <span class="star"></span>
                                          <span class="star"></span>';
							}
							echo '
                         </span>
                    </div>
                </div>
            </div>';
						}
					} elseif (empty($data)) {
						echo '<div class="container-fluid">
                                <div class="row">
                                    <div class="col-12" style="text-align: center">
                                        <h4>Vaša pretraga je prazna ili nemamo takav recept.</h4>
                                        <h6>Mi predlažemo sledeće recepte, pogledajte ih. <br> Ponovite pretragu.</h6>
                                    </div>
                                </div>
                              </div>';
						displayDailyRecipes(4);
					}
				}  else {
					echo '<div class="container-fluid">
                                <div class="row">
                                <div class="col-12" style="text-align: center">
                                <h3>Nismo pronašli rezultate Vaše pretrage.</h3>
                                Minimalna dužina riječi mora biti ' . $min_lenght . ' karaktera.
                            </div>
                            </div>
                            </div>';
					displayDailyRecipes(4);
				}
			}
		
		?>
    </div>
</div>
</section>
<footer style="margin-top:0;">
    <div class="row">
        <div class="col-sm-6 col-md-4 footer-navigation">
            <h3><a href="#" style="font-family:'Montserrat Alternates', sans-serif;">rECEPISTa</a></h3>
            <p class="links" style="font-family:'Montserrat Alternates', sans-serif;"><a href="#">Početna</a><strong> ·&nbsp;</strong><a
                        href="#">Novosti</a><strong> · </strong><a href="#">Recepti</a><strong>&nbsp;</strong><a
                        href="#"></a></p>
            <p class="company-name" style="font-family:'Montserrat Alternates', sans-serif;">rECEPISTa &nbsp;© 2018 Sva
                prava zadržana.</p>
        </div>
        <div class="col-sm-6 col-md-4 footer-contacts">
            <div>
                <h4 style="font-size:1rem;font-family:'Montserrat Alternates', sans-serif;">Gdje se nalazimo :</h4><span
                        class="fa fa-map-marker footer-contacts-icon"> </span>
                <p style="font-family:'Montserrat Alternates', sans-serif;"> Banja Luka - RS, BIH</p>
            </div>
            <div></div>
            <div>
                <h4 style="font-size:1rem;font-family:'Montserrat Alternates', sans-serif;">Pridruzite se timu!</h4>
                <p style="color:rgb(146,153,159);line-height:20px;font-size:13px;font-family:'Montserrat Alternates', sans-serif;font-weight:normal;">
                    Ukoliko želite da budete dio tima rECEPISTa pošaljite prijavu na sledeću adresu:</p>
                <p>
                    <i
                            class="fa fa-envelope footer-contacts-icon"></i>
                    <a href="#" target="_blank"
                       style="color:rgb(255,255,255);font-family:'Montserrat Alternates', sans-serif;">i-ja-sam@recepista.ba</a>
                </p>
            </div>
        </div>
        <div class="clearfix"></div>
        <div class="col-md-4 footer-about">
            <h4 style="font-size:1rem;font-family:'Montserrat Alternates', sans-serif;">O nama</h4>
            <p class="text-justify" style="font-family:'Montserrat Alternates', sans-serif;line-height:15px;"> Mi smo
                informativni portal za gurmane. Ovim portalom želimo da pojednostavimo i olakšamo svakondevnu borbu s
                pitanjem "Šta danas da skuhavmo?". Nadamo se da će Vam naši recepti pomoći i da će biti korisni kada ih
                zatrebate.</p>
            <div style="margin-bottom: 25px" class="social-links social-icons"><a href="#"><i
                            class="fa fa-facebook"></i></a></div>
            <form class="form-inline d-flex flex-row justify-content-center" method="post"
                  action="components/subscribe.php">
                <div class="form-group d-flex" style="width:100%;"><input class="form-control" type="email"
                                                                          name="email"
                                                                          placeholder="Vasa email adresa:"
                                                                          autocomplete="off">
                    <button class="btn btn-primary" type="submit" name="submit"
                            style="background-color:#33383b;border: 1px solid #a9a9a9">Pretplati me!
                    </button>
                </div>
            </form>
        </div>
    </div>
</footer>

<script src="assets/js/jquery.min.js"></script>
<script src="assets/bootstrap/js/bootstrap.min.js"></script>
<script src="https://unpkg.com/@bootstrapstudio/bootstrap-better-nav/dist/bootstrap-better-nav.min.js"></script>
</body>

</html>